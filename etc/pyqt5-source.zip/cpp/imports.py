from PyQt5.QtWidgets import *


from PyQt5.QtWidgets import QApplication, QWidget, QLineEdit, QPushButton, QHBoxLayout


from PyQt5 import QtWidgets

