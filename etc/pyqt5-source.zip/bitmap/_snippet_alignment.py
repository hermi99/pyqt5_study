painter.drawText(100, 100, 100, 100, Qt.AlignHCenter, 'Hello, world!')
