from PyQt5.QtGui import QPalette
palette = QPalette()